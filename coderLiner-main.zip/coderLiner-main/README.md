# coderLiner
This is a Website I created for fun to give a pickup line for coder on CS theme. Funny. Collected 555+ Lines with the help of CHATGPT and Web Scraping Knowledge and added with Bootstrap design to build this website
